Loto Analyseur Pro - Version 1.0
---------------------------------
Merci d'avoir téléchargé l'application.

Installation :
1. Double-cliquez sur LotoAnalyseurInstaller.msi
2. Suivez les instructions à l'écran pour installer le programme.
3. Lancez l'application depuis votre menu Démarrer.

Ce fichier est une démo. Le fichier MSI est factice et ne contient pas encore l'application réelle.
